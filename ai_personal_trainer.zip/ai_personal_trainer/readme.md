

A simple full-stack AI project using:
- FastAPI (Backend)
- Streamlit (Frontend)
- OpenAI API (AI plan generation)

---

## 🚀 Installation

### 1. Create virtual environment
